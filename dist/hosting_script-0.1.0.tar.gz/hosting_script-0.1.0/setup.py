# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['src']

package_data = \
{'': ['*']}

install_requires = \
['PyYAML>=6.0,<7.0', 'pydantic>=1.9.0,<2.0.0']

entry_points = \
{'console_scripts': ['host = src.main:main']}

setup_kwargs = {
    'name': 'hosting-script',
    'version': '0.1.0',
    'description': 'Automate hosting a Flask (for now) web server on a Raspberri Pi with an access point.',
    'long_description': None,
    'author': 'Jaren Glenn',
    'author_email': 'jarenglenn@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.9,<4.0',
}


setup(**setup_kwargs)
